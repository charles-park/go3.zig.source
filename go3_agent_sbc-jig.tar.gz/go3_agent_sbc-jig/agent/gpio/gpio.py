from gpio.pin import *

led_led = Pin(0x8, 0xc, "LED_RED")
led_blue = Pin(0x8, 0x8, "LED_BLUE")
led_green = Pin(0x19, 0xf, "LED_GREEN")
led_yellow = Pin(0x19, 0xb, "LED_YELLOW")

PIN_LEDS_SYS_C4 = [led_led, led_blue]
PIN_LEDS_ETH_C4 = [led_green, led_yellow]

VCC5 = Pin(0x18, 0xf, "V5")
VDDIO_AO1V8 = Pin(0x18, 0xb, "V18_AO")
VCC3V3 = Pin(0x18, 0xe, "V3")
VDDAO_3V3 = Pin(0x18, 0xa, "V3_AO")
VDDCPU = Pin(0x18, 0x9, "VDDCPU")
VDDEE = Pin(0x18, 0x8, "VDDEE")

CEC = Pin(0x19, 0xa, "CEC")
SCL = Pin(0x19, 0xe, "SCL")
SDA = Pin(0x19, 0xb, "SDA")
HPD = Pin(0x19, 0xf, "HPD")

fan_tacho = Pin(0x8, 0x8, "FAN_TACHO")
fan_pwm = Pin(0x8, 0xc, "FAN_PWM")
gpx3 = Pin(0x8, 0xb, "GPX3")
gpx17 = Pin(0x8, 0xd, "GPX17")
gpx18 = Pin(0x8, 0xa, "GPX18")
gpx5 = Pin(0x8, 0xe, "GPX5")

led_sys = Pin(0x19, 0x8, "SYS")
led_pwr = Pin(0x19, 0xc, "PWR")
led_eth_y = Pin(0x19, 0xd, "ETH_Y")
led_eth_g = Pin(0x19, 0x9, "ETH_G")
led_hdd = Pin(0x8, 0xf, "LED_HDD")

PIN_GPIOS_HC4 = [fan_tacho, fan_pwm, gpx3, gpx17, gpx18, gpx5]
#PIN_PWR_HC4 = [VCC5, VDDIO_AO1V8, VCC3V3, VDDAO_3V3, VDDCPU, VDDEE]
PIN_PWR_HC4 = [VCC3V3, VCC5]
PIN_HDMI_HC4 = [CEC, SCL, SDA, HPD]
PIN_LED_ETH = [led_eth_y, led_eth_g]
PIN_LED_SYS = [led_sys, led_pwr]
PIN_LED_HDD = [led_hdd]

GO3_LED_SYS = Pin(0x19, 0x8, "SYS", 0.8, 0.15)
GO3_LED_PWR = Pin(0x19, 0xc, "PWR", 0.8, 0.1)
GO3_LED_CHG = Pin(0x19, 0x9, "CHG", 0.8, 0.1)
GO3_SW1 = Pin(0x8, 0xd, "1")
GO3_SW2 = Pin(0x8, 0xe, "2")
GO3_SW3 = Pin(0x8, 0xb, "3")
GO3_SW4 = Pin(0x8, 0x9, "4")
GO3_SW5 = Pin(0xb, 0xa, "5")
GO3_SW6 = Pin(0xb, 0xe, "6")
GO3_SW7 = Pin(0xb, 0x9, "7")
GO3_SW8 = Pin(0xb, 0xd, "8")
GO3_SW11 = Pin(0x8, 0x8, "11")
GO3_SW12 = Pin(0x8, 0xc, "12")
GO3_SW13 = Pin(0xb, 0xb, "13")
GO3_SW14 = Pin(0xb, 0xf, "14")
GO3_P2_2 = Pin(0x18, 0xf, "2")
GO3_P2_3 = Pin(0x18, 0xb, "3")
GO3_P2_4 = Pin(0x18, 0xe, "4")
GO3_P2_5 = Pin(0x18, 0xa, "5")
GO3_P2_7 = Pin(0x18, 0xd, "7")
GO3_P2_8 = Pin(0x18, 0x9, "8")
GO3_P2_9 = Pin(0x18, 0xc, "9")

GO3_VCC3V0 = Pin(0x9, 0xc, "V3")
GO3_VCC5 = Pin(0x9, 0x8, "V5")
GO3_DC = Pin(0x9, 0x9, "V5_DC")
GO3_BAT = Pin(0x19, 0xb, "BAT")
GO3_HP_L = Pin(0xa, 0xd, "HP_L")
GO3_HP_R = Pin(0xa, 0x9, "HP_R")
GO3_SPK_L = Pin(0xa, 0x8, "SPK_L")
GO3_SPK_R = Pin(0xa, 0xc, "SPK_R")
GO3_AUDIO = {'hp_l':GO3_HP_L, 'hp_r':GO3_HP_R, 'spk_l':GO3_SPK_L, 'spk_r':GO3_SPK_R}

GO3_SW = [GO3_SW1, GO3_SW2, GO3_SW3, GO3_SW4, GO3_SW5, GO3_SW6, GO3_SW7,
        GO3_SW8, GO3_SW11, GO3_SW12, GO3_SW13, GO3_SW14]
GO3_P2 = [GO3_P2_2, GO3_P2_3, GO3_P2_4, GO3_P2_5, GO3_P2_7, GO3_P2_8, GO3_P2_9]
#GO3_PWR = [GO3_VCC3V0, GO3_VCC5, GO3_DC, GO3_BAT]
GO3_PWR = [GO3_VCC3V0, GO3_BAT]
GO3_PUSH_BTN = ['TL', 'TL2', 'TR', 'TR2', 'V_DOWN', 'V_UP', 'F1', 'F2']
class GPIO():
    def __init__(self, model):
        if model == 'HC4':
            self.gpio = PIN_GPIOS_HC4
            self.hdmi = PIN_HDMI_HC4
            self.pwrs = PIN_PWR_HC4
            self.leds_eth = PIN_LED_ETH
            self.leds_sys = PIN_LED_SYS
            self.led_hdd = PIN_LED_HDD
        elif model == 'GO3':
            self.led_sys = GO3_LED_SYS
            self.led_pwr = GO3_LED_PWR
            self.led_chg = GO3_LED_CHG
            self.pwrs = GO3_PWR
            self.keypads = GO3_SW
            self.pin10 = GO3_P2
            self.audio = GO3_AUDIO
