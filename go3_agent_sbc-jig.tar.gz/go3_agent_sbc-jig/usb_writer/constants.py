PATH_PREFFIX = '/sys/bus/usb/devices/'

PATH_RESET_USB = '/sys/devices/platform/gpio-reset/reset-usb_hub/control'


