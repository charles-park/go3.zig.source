from utils.log import init_logger

LOG = init_logger('adc', 'info')

HIGH = 2.5
LOW = 1.5

HIGH_V5 = 4.2
HIGH_V3 = 3
HIGH_V18 = 1.8
VDDEE = 0.85
VDDCPU = 1
