from smbus2 import SMBus
import asyncio
from .constants import *
import time
from asyncio import ensure_future as asyncef
from asyncio import ensure_future as aef

class ADC():
    def __init__(self, bus=None):
        self.loop = asyncio.get_event_loop()
        self.lock_adc = {0x8: 0, 0x9: 0, 0xa: 0, 0xb: 0, 0x18: 0, 0x19: 0}
        self.channel = bus

        try:
            self.bus = SMBus(bus)
        except FileNotFoundError as e:
            print(f'file no found {e}')
        except IOError as e:
            print(f'io error {e}')

    async def lock(self, addr):
        while self.lock_adc[addr] != 0:
            await asyncio.sleep(0.01)
        self.lock_adc[addr] = 1

    async def unlock(self, addr):
        self.lock_adc[addr] = 0

    async def read_power(self, pwrs):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in pwrs]
        result = (await asyncio.gather(*res))
        off = []
        bat = 0
        for i in result:
            if i[0].startswith("V5"):
                if i[1] < HIGH_V5:
                    off.append(i[0])
                    LOG.debug(f"{self.channel} : {i}")
            elif i[0].startswith("V3"):
                if i[1] < HIGH_V3*0.8 or i[1] > HIGH_V3*1.3:
                    off.append(i[0])
                    LOG.debug(f"{self.channel} : {i}")
            elif i[0].startswith("V18"):
                if i[1] < HIGH_V18*0.8 or i[1] > HIGH_V18*1.2:
                    off.append(i[0])
                    LOG.error(f"{self.channel} : {i}")
            elif i[0].startswith("VDDCPU"):
                if i[1] < VDDCPU*0.8 or i[1] > VDDCPU*1.2:
                    off.append(i[0])
                    LOG.error(f"{self.channel} : {i}")
            elif i[0].startswith("BAT"):
                bat = i[1]
        return off, bat

    async def check_eth_led(self, leds, speed):
        count = 0
        ret = []
        while count < 30:
            ret = await self._check_eth_led(leds, speed)
            if len(ret) == 0:
                return ret
            count += 1
            await asyncio.sleep(0.5)
        return ret

    async def _check_eth_led(self, leds, speed):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in leds]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if i[0] == "ETH_Y" and speed  == 1000:
                if i[1] < 0.6:
                    fail.append(i[0])
                    LOG.error(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "ETH_Y" and speed  == 100:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.error(f"High failed {i[0]} : {i[1]}")

            if i[0] == "ETH_G" and speed  == 1000:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.error(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "ETH_G" and speed == 100:
                if i[1] < 0.6:
                    fail.append(i[0])
                    LOG.error(f"LOW failed {i[0]} : {i[1]}")
        return fail

    async def check_hdd_led(self, leds, seq):
        count = 0
        ret = []
        while count < 30:
            ret = await self._check_hdd_led(leds, seq)
            if len(ret) == 0:
                return ret
            count += 1
            await asyncio.sleep(0.5)
        return ret

    async def _check_hdd_led(self, leds, seq):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in leds]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if seq == 0:
                if i[1] > 0.2:
                    fail.append(i[0])
                    LOG.error(f"{self.channel} Low failed {i[0]} : {i[1]}")
            elif seq == 1:
                if i[1] < 0.8:
                    fail.append(i[0])
                    LOG.error(f"{self.channel} High failed {i[0]} : {i[1]}")
        return fail

    async def check_led(self, led, onoff):
        count = 0
        while count < 30:
            ret = await self._read(led.addr, led.channel, led.label)
            if onoff == 0:
                if ret[1] > led.low:
                    LOG.error(f'Low fail {ret[0]} : {ret[1]}')
                else:
                    LOG.debug(f'Low okay {ret[0]} : {ret[1]}')
                    return 0
            elif onoff == 1:
                if ret[1] < led.high:
                    LOG.error(f'High fail {ret[0]} : {ret[1]}')
                else:
                    LOG.debug(f'High okay {ret[0]} : {ret[1]}')
                    return 0
            count += 1
            await asyncio.sleep(0.5)
        return 1

    async def _read_bulk(self, pin):
        res = [aef(self._read(pin.addr, pin.channel, pin.label)) for i in range(20)]
        result = (await asyncio.gather(*res))
        return result

    async def is_off_spk(self, pin):
        cnt = 0
        while cnt < 15:
            r = await self._read_bulk(pin)
            cond0 = len([x for x in r if x[1] > 2 and x[1] < 4])
            cond1 = len([x for x in r if x[1] < 0.3])
            if cond0 == 20 or cond1 == 20:
                avg = sum([x[1] for x in r])/len(r)
                LOG.warn(f'SPK is off {pin.label} {cond0} {cond1} {avg}')
                return 1
            else:
                avg = sum([x[1] for x in r])/len(r)
                LOG.error(f'SPK is not off {pin.label} {cond0} {cond1} {avg}')
            cnt += 1
        return 0

    async def is_on_spk(self, pin):
        cnt = 0
        while cnt < 15:
            r = await self._read_bulk(pin)
            val = len([x for x in r if x[1] > 4.3])
            if val > 5:
                avg = sum([x[1] for x in r])/len(r)
                LOG.warn(f'SPK is on {pin.label} {val} {avg}')
                return 1
            else:
                avg = sum([x[1] for x in r])/len(r)
                LOG.error(f'SPK is not on {pin.label} {val} {avg}')
            cnt += 1
        return 0

    async def is_off_hp(self, pin):
        cnt = 0
        while cnt < 15:
            r = await self._read_bulk(pin)
            cond0 = len([x for x in r if x[1] < 0.3])
            cond1 = len([x for x in r if x[1] > 0.3 and x[1] < 0.6])
            if cond0 == 20 or cond1 == 20:
                avg = sum([x[1] for x in r])/len(r)
                LOG.warn(f'Hp is off {pin.label} {cond0} {cond1} {avg}')
                return 1
            else:
                avg = sum([x[1] for x in r])/len(r)
                LOG.error(f'HP is not off {pin.label} {cond0} {cond1} {avg}')
            cnt += 1
        return 0

    async def is_on_hp(self, pin):
        cnt = 0
        while cnt < 15:
            r = await self._read_bulk(pin)
            val = len([x for x in r if x[1] > 0.65])
            if val > 0:
                avg = sum([x[1] for x in r])/len(r)
                LOG.warn(f'Hp is on {pin.label} {val} {avg}')
                return 1
            else:
                avg = sum([x[1] for x in r])/len(r)
                LOG.error(f'Hp is not on {pin.label} {val} {avg}')
            cnt += 1
        return 0

    async def check_on_hp(self, pins):
        ret, defects = await self._check_audio(pins, spk_on=0, hp_on=1)
        return ret, defects

    async def check_on_spk(self, pins):
        ret, defects = await self._check_audio(pins, spk_on=1, hp_on=0)
        return ret, defects

    async def check_on_spk_hp(self, pins):
        ret, defects = await self._check_audio(pins, spk_on=1, hp_on=1)
        return ret, defects

    async def check_off_spk_hp(self, pins):
        ret, defects = await self._check_audio(pins, spk_on=0, hp_on=0)
        return ret, defects

    async def _check_audio(self, pins, spk_on, hp_on):
        count = 0
        func_spk = [self.is_off_spk, self.is_on_spk]
        func_hp = [self.is_off_hp, self.is_on_hp]
        defect = []
        r = await func_spk[spk_on](pins['spk_l'])
        if r != 1:
            defect.append('spk_l')
        r = await func_spk[spk_on](pins['spk_r'])
        if r != 1:
            defect.append('spk_r')
        r = await func_hp[hp_on](pins['hp_l'])
        if r != 1:
            defect.append('hp_l')
        r = await func_hp[hp_on](pins['hp_r'])
        if r != 1:
            defect.append('hp_r')
        if len(defect) == 0:
            return 0, None
        LOG.error(",".join(defect))
        return 1, defect


    async def _check_led(self, leds, seq):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in leds]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if i[0] == "SYS" and seq == 0:
                if i[1] < 1.0:
                    fail.append(i[0])
                    LOG.error(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "SYS" and seq == 1:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.error(f"Low failed {i[0]} : {i[1]}")

            if i[0] == "PWR" and seq == 0:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.error(f"Low failed {i[0]} : {i[1]}")
            elif i[0] == "PWR" and seq == 1:
                if i[1] < 1.5:
                    fail.append(i[0])
                    LOG.error(f"High failed {i[0]} : {i[1]}")
        return fail

    async def check_hdmi(self, pins, seq):
        count = 0
        ret = []
        while count < 5*2:
            ret = await self._check_hdmi(pins, seq)
            if len(ret) == 0:
                break
            count += 1
            await asyncio.sleep(0.5)
        return ret

    async def _check_hdmi(self, pins, seq):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in pins]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if seq == 0:
                if i[0] == "CEC":
                    if i[1] < HIGH:
                        fail.append(i)
                        LOG.error(f"High failed {i[0]} : {i[1]}")
                else:
                    if i[1] > LOW:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
            elif seq == 1:
                if i[0] == "SCL":
                    if i[1] < HIGH:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
                else:
                    if i[1] > LOW:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
            elif seq == 2:
                if i[0] == "SDA":
                    if i[1] < HIGH:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
                else:
                    if i[1] > LOW:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
            elif seq == 3:
                if i[0] == "HPD":
                    if i[1] < HIGH:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
                else:
                    if i[1] > LOW:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
        return fail

    async def check_pwr(self, pwrs):
        while True:
            off, bat = await self.read_power(pwrs)
            if len(off) != 0:
                LOG.debug(off)
                yield 0, bat
            else:
                yield 1, bat
            await asyncio.sleep(1)

    async def read_pin(self, pins, label):
        for i in pins:
            if i.label == label:
                ret = await self._read(i.addr, i.channel, i.label)
                print(ret)

    async def read(self, pins, label):
        try:
            res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in pins]
            result = (await asyncio.gather(*res))
            fail = []
            for i in result:
                if i[0] == label:
                    if i[1] < HIGH:
                        fail.append(i[0])
                        LOG.error(f"High failed {i[0]} : {i[1]}")
                else:
                    if i[1] > LOW:
                        fail.append(i[0])
                        LOG.error(f"Low failed {i[0]} : {i[1]}")
        except Exception as e:
            print(e)
        return fail

    async def read_times(self, pins, label):
        count = 0
        while count < 10:
            ret = await self.read(pins, label)
            if len(ret) == 0:
                return 0
            count += 1
            await asyncio.sleep(0.5)
        return ret

    async def read_chip(self, addr):
        ch = [0xf, 0xb, 0xe, 0xa, 0xd, 0x9, 0xc, 0x8]
        result = []
        for idx, i in enumerate(ch):
            result.append(await self._read(addr, i, idx))
        print(result)

    async def _read(self, addr, channel, label):
        await self.lock(addr)
        channel = (channel << 4) | 0x8
        await asyncio.sleep(0.001)
        try:
            self.bus.write_byte(addr, channel)
            await asyncio.sleep(0.001)
            reading = self.bus.read_i2c_block_data(addr, channel, 2)
            await self.unlock(addr)
        except OSError as e:
            await self.unlock(addr)
            return label, -1
        except Exception as e:
            await self.unlock(addr)
            return label, -1
        valor = (reading[0] << 4) + (reading[1] >> 4)
        volt = float(f'{valor*5.1/4096:0.2f}')
        return label, volt
