from uart import Uart
from adc import ADC
from odroid_factory_api import API_MANAGER
from utils.log import init_logger
import asyncio
from asyncio import ensure_future as aef
#from board import HC4
from board import GO3
from copy import deepcopy
import sys, os, time
import cups
from datetime import datetime

LOG = init_logger('', testing_mode='info')

from kivy.uix.boxlayout import BoxLayout
from kivy.app import App
from kivy.config import Config
from kivy.properties import ObjectProperty
from kivy.lang import Builder

Config.set('graphics', 'fullscreen', 'auto')
Config.set('graphics', 'borderless', 0)
Config.set('graphics', 'allow_screensaver', 0)

os.environ['DISPLAY'] = ":0.0"

FORUM = 'forum.odroid.com'

BOARD = 'go3'
UI_KV = f'{BOARD}.kv'

class AgentApp(App):
    def build(self):
        Builder.load_file(UI_KV)
        av = AgentView()
        aef(av.init())
        return av

    def app_func(self):
        async def run_wrapper():
            await self.async_run(async_lib='asyncio')
        return asyncio.gather(run_wrapper())

class AgentView(BoxLayout):
    async def init(self):
        self.agent = []
        for i in range(2):
            self.agent.append(Agent(i))
            await self.agent[i].init_tasks()
            self.ids[f'ch{i}'].name.text = f'CH{i}'
            self.ids[f'ch{i}'].init(self.agent[i])
            aef(self.update(self.ids[f'ch{i}']))

        aef(self.monitor_ip())
        #aef(self.monitor_counts())
        aef(self.monitor_dates())

    async def update(self, channel):
        while True:
            channel.update()
            await asyncio.sleep(0.5)

    async def monitor_dates(self):
        while True:
            '''
            conn = cups.Connection()
            p = conn.getPrinters()
            p_state = p['ZTC-GC420d-EPL']['printer-state']
            '''
            x = datetime.now()
            self.ids['date'].text = x.strftime("%Y-%m-%d %H:%M")
            await asyncio.sleep(1)

    async def monitor_counts(self):
        api_manager = API_MANAGER(board=BOARD)
        while True:
            cnt = await api_manager.get_counts(
                    filter='today')
            self.ids['cnt_today'].text = str(cnt)
            await asyncio.sleep(10)

    async def monitor_ip(self):
        ipaddr = None
        while True:
            _ipaddr = await self.get_ipaddr()
            if ipaddr != _ipaddr:
                ipaddr = _ipaddr
                if ipaddr.startswith('192.168'):
                    self.ids['ipaddr'].background_color = (0, 1, 0, 0.8)
                else:
                    self.ids['ipaddr'].background_color = (1, 0, 0, 0.8)
                self.ids['ipaddr'].text = ipaddr
            await asyncio.sleep(5)

    async def get_ipaddr(self):
        ipaddr = None
        cmd = 'hostname -I'
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            LOG.error(stderr)
        return stdout.decode('utf-8').rstrip()

class Channel(BoxLayout):
    def __init__(self, **kwargs):
        self.agent = None
        self.items = None
        super(Channel, self).__init__(**kwargs)

    def init(self, agent):
        self.agent = agent
        self.items = self.agent.items

    def switch_callback(self, active):
        self.agent.sw_joystick = active

    def draw(self, label):
        self.items[label].update = 0
        if self.items[label].okay == 1:
            self.ids[label].background_color = (0, 1, 0, 0.8)
        elif self.items[label].okay == 2:
            self.ids[label].background_color = (1, 1, 0, 0.8)
        elif self.items[label].okay == 3:
            self.ids[label].background_color = (1, 1, 0, 1)
        elif self.items[label].okay == None:
            self.ids[label].background_color = (.2, .4, .7, .9)
        else:
            self.ids[label].background_color = (1, 0, 0, 0.8)

        if self.items[label].flag_text == 1:
            if self.items[label].value != str:
                self.ids[label].text = str(self.items[label].value)
            else:
                self.ids[label].text = self.items[lable].value
        elif self.items[label].flag_text == 2:
            if self.items[label].tmp != str:
                self.ids[label].text = str(self.items[label].tmp)
            else:
                self.ids[label].text = self.items[lable].tmp


    def update(self):
        for k, v in self.items.items():
            if k == 'push_btn':
                continue
            if v.update == 1:
                self.draw(k)

class Agent(GO3):
    def __init__(self, channel=0):
        super().__init__()
        self.channel = channel
        self.uart = Uart(channel, self.model)
        self.adc = ADC(channel)

        self.time = time.time()

        self.ipaddr = None
        self.power_on = None

        self.seq_main = 0

    def pick_time(self):
        return round(time.time() - self.time, 2)

    async def wait_ack(self, item, time=10):
        item.req = self.pick_time()
        item.ret = None
        count = 0
        while True:
            if item.ack != None:
                return 0
            if count > time*2:
                item.okay = 0
                item.value = "No ACK"
                item.tmp = ""
                item.update = 1
                return -1
            count += 1
            await asyncio.sleep(0.5)

    async def wait_ret(self, item, time=10):
        count = 0
        while True:
            if item.ret != None:
                return 0
            if count > time*2:
                item.okay = 0
                item.value = "No RET"
                item.tmp = ""
                item.update = 1
                return -1
            count += 1
            await asyncio.sleep(0.5)

    def fail_items(self, items, value=None):
        if type(items) == str:
            if value != None:
                self.items[items].value = value
            self.items[items].okay = 0
            self.items[items].update = 1
        elif type(items) == list:
            for label in items:
                if value != None:
                    self.items[label].value = value
                self.items[label].okay = 0
                self.items[label].update = 1

    def okay_items(self, items, value=None):
        if type(items) == str:
            if value != None:
                self.items[items].value = value
            self.items[items].okay = 1
            self.items[items].update = 1
        elif type(items) == list:
            for label in items:
                if value != None:
                    self.items[label].value = value
                self.items[label].okay = 1
                self.items[label].update = 1

    async def init_tasks(self):
        aef(self.uart.available_uart())
        aef(self.parse_msg())
        aef(self.sequence_main())
        aef(self.monitor_pwr())

    async def init_sequence(self):
        self.seq_main = 0
        self.time = time.time()
        self.init_variables()

    async def parse_usb(self, cmd, data, size):
        if cmd == 'ack':
            if data[0] == 'speed':
                self.items['usb2'].ack = self.pick_time()
        elif cmd == 'ret':
            if data[0] == 'speed':
                self.items['usb2'].ret = self.pick_time()
                self.items['usb2'].value = data[1]
                LOG.info(self.items['usb2'].value)

    async def parse_component(self, cmd, data, size):
        if cmd == 'ack':
            self.items[data[0]].ack = self.pick_time()
        elif cmd == 'ret':
            self.items[data[0]].ret = self.pick_time()
            self.items[data[0]].value = data[1]
            if size > 2:
                self.items[data[0]].tmp = data[2:]

    async def parse_msg(self):
        async for cmd, data in self.uart.recv():
            if data == None:
                continue
            size = len(data)
            if size < 1:
                continue
            if cmd == 'boot' and data[0] == 'done':
                await self.init_sequence()
                self.seq_main = 1

            if data[0] in self.btns:
                if self.items[data[0]].value != None:
                    self.items[data[0]].tmp = data[1]
                else:
                    self.items[data[0]].value = data[1]
            else:
                aef(self.parse_component(cmd, data, size))


async def main():
    await AgentApp().app_func()

if __name__ == "__main__":
    asyncio.run(main())
